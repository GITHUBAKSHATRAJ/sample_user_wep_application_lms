package org.mindrot.jbcrypt;

public class BCrypt {

}
