document.getElementById('grade-form').addEventListener('submit', function (e) {
    e.preventDefault();
    alert('Grade submitted successfully!');
});
